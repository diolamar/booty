# ============ FILE: bet.py (COMPLETE ENHANCED VERSION) ============
import tkinter as tk
from tkinter import messagebox, ttk
import ctypes
from ctypes import wintypes
import pyautogui
import json
import csv
import os
import shutil
import sys
import time
import random
import threading
from pathlib import Path
from PIL import ImageGrab, ImageTk
from typing import Dict, List, Tuple, Optional
import logging
from datetime import datetime
from collections import Counter
import traceback
import statistics

from autoclick_runtime import (
    ClickPlanError,
    build_bet_plan,
    create_click_actions,
    format_bet_plan,
    perform_click_actions,
)
from capture import ColorMatcher, GameAnalyzer, ScreenCaptureManager
from models import (
    AppConfig,
    AutomationState,
    CalibrationPoint,
    GameState,
    ThreadSafeState,
    DecisionRecord,
    DecisionStats,
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(threadName)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


APP_NAME = "AutoClickerPro"
GRAY_COOLDOWN_SECONDS = 280.0


if os.name == "nt":
    user32 = ctypes.windll.user32
    SW_RESTORE = 9
    SWP_NOMOVE = 0x0002
    SWP_NOSIZE = 0x0001
    SWP_SHOWWINDOW = 0x0040
    HWND_TOPMOST = -1


def _get_window_text(hwnd: int) -> str:
    if os.name != "nt":
        return ""

    length = user32.GetWindowTextLengthW(hwnd)
    if length <= 0:
        return ""

    buffer = ctypes.create_unicode_buffer(length + 1)
    user32.GetWindowTextW(hwnd, buffer, len(buffer))
    return buffer.value.strip()


def find_brave_window() -> Optional[int]:
    if os.name != "nt":
        return None

    matches: List[int] = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def enum_windows_proc(hwnd, _lparam):
        if not user32.IsWindowVisible(hwnd):
            return True

        title = _get_window_text(hwnd)
        if title and "brave" in title.lower():
            matches.append(hwnd)
        return True

    user32.EnumWindows(enum_windows_proc, 0)
    return matches[0] if matches else None


def force_brave_window_on_top() -> bool:
    if os.name != "nt":
        return False

    hwnd = find_brave_window()
    if not hwnd:
        return False

    if user32.IsIconic(hwnd):
        user32.ShowWindow(hwnd, SW_RESTORE)

    user32.SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW)
    user32.BringWindowToTop(hwnd)
    user32.SetForegroundWindow(hwnd)
    return True


def get_runtime_data_dir() -> Path:
    """Return a writable directory for runtime data in both .py and .exe modes."""
    if getattr(sys, "frozen", False):
        local_app_data = os.getenv("LOCALAPPDATA")
        if local_app_data:
            return Path(local_app_data) / APP_NAME
        return Path.home() / "AppData" / "Local" / APP_NAME

    return Path(__file__).resolve().parent / "config"


def get_legacy_config_dir() -> Path:
    """Old save location used before the executable-safe path fix."""
    base_path = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
    return base_path / "config"


def ensure_runtime_data_dir() -> Path:
    runtime_dir = get_runtime_data_dir()
    runtime_dir.mkdir(parents=True, exist_ok=True)
    return runtime_dir


def migrate_legacy_runtime_files(runtime_dir: Path):
    """Copy old config/calibration files into the new writable runtime directory once."""
    legacy_dir = get_legacy_config_dir()
    if legacy_dir.resolve() == runtime_dir.resolve() or not legacy_dir.exists():
        return

    for filename in ("app_config.json", "calibration.json", "calibration_frame.png", "simulate_results.csv", "simulate_round_detector.png"):
        source_path = legacy_dir / filename
        target_path = runtime_dir / filename
        if source_path.exists() and not target_path.exists():
            try:
                shutil.copy2(source_path, target_path)
            except Exception as exc:
                logger.warning(f"Failed to migrate {source_path} to {target_path}: {exc}")


def configure_file_logging(runtime_dir: Path):
    """Persist standard logger output to the runtime directory."""
    log_path = runtime_dir / "application.log"
    resolved_log_path = str(log_path.resolve())

    for handler in logger.handlers:
        if isinstance(handler, logging.FileHandler) and getattr(handler, "baseFilename", None) == resolved_log_path:
            return

    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(logging.Formatter('%(asctime)s - %(threadName)s - %(levelname)s - %(message)s'))
    logger.addHandler(file_handler)


class EventLogger:
    """Centralized event logging with AI-friendly format"""
    
    def __init__(self, config_dir: Path):
        self.config_dir = config_dir
        self.logs_dir = config_dir / "logs"
        self.logs_dir.mkdir(parents=True, exist_ok=True)
        
        self.session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.ai_log_path = self.logs_dir / f"ai_debug_{self.session_id}.log"
        self.event_csv_path = self.logs_dir / f"events_{self.session_id}.csv"
        self.error_log_path = self.logs_dir / f"errors_{self.session_id}.log"
        
        self._init_event_csv()
        self.recent_events = []
        self.max_recent_events = 100
        
    def _init_event_csv(self):
        with open(self.event_csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow([
                "Timestamp", "Event Type", "Description", 
                "Round", "Bet Color", "Bet Amount", 
                "Result", "C1 Boxes", "Matches", "Multiplier", 
                "Profit", "Total Profit", "Loss Streak"
            ])
    
    def log_event(self, event_type: str, description: str, **kwargs):
        timestamp = datetime.now().isoformat()
        
        log_entry = {
            "timestamp": timestamp,
            "session_id": self.session_id,
            "event_type": event_type,
            "description": description,
            "data": kwargs
        }
        
        with open(self.ai_log_path, 'a', encoding='utf-8') as f:
            f.write(json.dumps(log_entry, ensure_ascii=False) + "\n")
        
        self._append_to_csv(timestamp, event_type, description, kwargs)
        
        self.recent_events.insert(0, {
            "timestamp": timestamp,
            "type": event_type,
            "description": description,
            "data": kwargs
        })
        self.recent_events = self.recent_events[:self.max_recent_events]
    
    def _append_to_csv(self, timestamp: str, event_type: str, description: str, data: dict):
        try:
            with open(self.event_csv_path, 'a', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow([
                    timestamp, event_type, description,
                    data.get("round_number", ""),
                    data.get("bet_color", ""),
                    data.get("bet_amount", ""),
                    data.get("result", ""),
                    data.get("c1_boxes", ""),
                    data.get("matches", ""),
                    data.get("multiplier", ""),
                    data.get("profit_change", ""),
                    data.get("total_profit", ""),
                    data.get("loss_streak", "")
                ])
        except Exception as e:
            print(f"CSV write error: {e}")
    
    def log_error(self, error_type: str, error: Exception, context: dict = None):
        timestamp = datetime.now().isoformat()
        
        error_entry = {
            "timestamp": timestamp,
            "session_id": self.session_id,
            "error_type": error_type,
            "error_message": str(error),
            "context": context or {},
            "traceback": traceback.format_exc()
        }
        
        with open(self.error_log_path, 'a', encoding='utf-8') as f:
            f.write(json.dumps(error_entry, ensure_ascii=False, indent=2) + "\n")
            f.write("="*80 + "\n")
        
        self.log_event("ERROR", f"{error_type}: {str(error)}", **{k: str(v) for k, v in (context or {}).items()})
    
    def export_for_ai(self) -> str:
        export_data = {
            "session_id": self.session_id,
            "export_time": datetime.now().isoformat(),
            "logs_directory": str(self.logs_dir),
            "log_files": {
                "ai_debug": str(self.ai_log_path),
                "events_csv": str(self.event_csv_path),
                "errors": str(self.error_log_path)
            },
            "recent_events": self.recent_events[:50]
        }
        return json.dumps(export_data, indent=2, ensure_ascii=False)
    
    def get_session_summary(self) -> str:
        summary = {
            "session_id": self.session_id,
            "start_time": self.session_id.replace("_", " "),
            "log_directory": str(self.logs_dir),
            "recent_events_count": len(self.recent_events)
        }
        return json.dumps(summary, indent=2)


class AutomationEngine:
    def __init__(self, config: AppConfig, capture_mgr: ScreenCaptureManager, 
                 color_matcher: ColorMatcher, game_analyzer: GameAnalyzer, 
                 app: Optional['AutoClickerPro'] = None):
        self.config = config
        self.capture_mgr = capture_mgr
        self.game_analyzer = game_analyzer
        self.app = app
        self.state = ThreadSafeState()
        
        self._monitor_thread: Optional[threading.Thread] = None
        self._simulate_thread: Optional[threading.Thread] = None
        self._autoclick_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._simulate_halted = False
        self.last_bet_color: Optional[str] = None
        self.last_bet_value: Optional[str] = None
        self.last_bet_amount: Optional[str] = None
        self.last_result: Optional[str] = None
        self.last_c1_boxes: List[str] = []
        self.c1_history: List[List[str]] = []
        self.pending_round_number = 1
        self.round_count = 0
        self.win_count = 0
        self.lose_count = 0
        self.profit_total = 0.0
        self.loss_streak = 0
        self.bet_amount_steps = self._build_virtual_bet_steps(
            start=self.config.martingale_start,
            max_steps=self.config.martingale_max_steps,
            flat_cap=self.config.max_bet_per_round,
        )
        self.martingale_index = 0
        self.max_loss_streak = len(self.bet_amount_steps)
        self.last_prediction = "None"
        self.last_decision_reason = "Waiting for C1 history"
        self.last_decision_score = 0.0
        self.last_decision_gap = 0.0
        self.last_skip_reason = ""
        
        # NEW: Decision tracking
        self.decision_history: List[DecisionRecord] = []
        self.decision_stats = DecisionStats()
        self.learning_mode = False
        self.last_decision_time = 0.0
        
        # Performance metrics
        self.start_time = time.time()
        self.total_clicks = 0
        self.last_performance_log = time.time()
        
        # Session recovery
        self._load_session_state()

    @staticmethod
    def _build_virtual_bet_steps(start: int, max_steps: int, flat_cap: Optional[int] = None) -> List[int]:
        steps = [start]
        while len(steps) < max_steps:
            next_step = (steps[-1] * 2) + start
            if flat_cap is not None:
                next_step = min(next_step, flat_cap)
            steps.append(next_step)
        return steps

    @staticmethod
    def _thread_is_running(thread: Optional[threading.Thread]) -> bool:
        return thread is not None and thread.is_alive()

    def _stop_worker_threads(self, timeout: float = 2.5):
        for thread in (self._monitor_thread, self._simulate_thread, self._autoclick_thread):
            if self._thread_is_running(thread):
                thread.join(timeout=timeout)

    def _ensure_brave_on_top(self, context: str = ""):
        if force_brave_window_on_top():
            if context:
                logger.debug("Brave forced on top for %s", context)
        elif context:
            logger.debug("Brave window not found for %s", context)
    
    def _load_session_state(self):
        if self.app and hasattr(self.app, 'config_dir'):
            session_path = self.app.config_dir / "session_backup.json"
            if session_path.exists():
                try:
                    with open(session_path, 'r') as f:
                        session = json.load(f)
                    self.round_count = session.get("round_count", 0)
                    self.profit_total = session.get("profit_total", 0.0)
                    self.loss_streak = session.get("loss_streak", 0)
                    self.martingale_index = session.get("martingale_index", 0)
                    self.c1_history = session.get("c1_history", [])
                    logger.info(f"Session recovered: {self.round_count} rounds, profit: {self.profit_total:.2f}")
                except Exception as e:
                    logger.error(f"Failed to load session: {e}")
    
    def _save_session_state(self):
        if self.app and hasattr(self.app, 'config_dir'):
            session = {
                "round_count": self.round_count,
                "profit_total": self.profit_total,
                "loss_streak": self.loss_streak,
                "martingale_index": self.martingale_index,
                "c1_history": self.c1_history[-30:],
                "timestamp": datetime.now().isoformat()
            }
            try:
                session_path = self.app.config_dir / "session_backup.json"
                with open(session_path, 'w') as f:
                    json.dump(session, f, indent=2)
                logger.debug("Session state saved")
            except Exception as e:
                logger.error(f"Failed to save session: {e}")
    
    def _log_performance(self):
        if self.round_count > 0 and self.round_count % 100 == 0:
            elapsed = time.time() - self.start_time
            clicks_per_sec = self.total_clicks / elapsed if elapsed > 0 else 0
            rounds_per_hour = (self.round_count / elapsed) * 3600 if elapsed > 0 else 0
            logger.info(f"Performance: {clicks_per_sec:.2f} clicks/sec, {rounds_per_hour:.1f} rounds/hour")
            
            if hasattr(self.app, 'color_matcher'):
                cache_stats = self.app.color_matcher.get_cache_stats()
                logger.info(f"Color cache: {cache_stats['hit_rate']:.1f}% hit rate ({cache_stats['hits']} hits)")
    
    def _check_bet_limits(self, amount: int) -> bool:
        if amount > self.config.max_bet_per_round:
            self.state.update_status(f"Bet {amount} exceeds max {self.config.max_bet_per_round}")
            return False
        
        if self.config.loss_limit and self.profit_total <= -self.config.loss_limit:
            self.state.update_status(f"Loss limit reached: ${self.profit_total:.2f}")
            self._stop_event.set()
            return False
        
        if self.config.profit_target and self.profit_total >= self.config.profit_target:
            self.state.update_status(f"Profit target reached: ${self.profit_total:.2f}")
            self._stop_event.set()
            return False
        
        return True

    def start_monitoring(self) -> bool:
        if not self.capture_mgr.is_fully_calibrated():
            return False
        if not self.capture_mgr.validate_calibration():
            self.state.update_status("Calibration validation failed - points off-screen")
            return False
        if self._monitor_thread and self._monitor_thread.is_alive():
            return True
        self._stop_event.clear()
        self._clear_pending_bet()
        self.state.state = AutomationState.MONITORING
        self._monitor_thread = threading.Thread(target=self._monitor_loop, name="MonitorThread", daemon=True)
        self._monitor_thread.start()
        return True
    
    def stop_all(self):
        self._stop_event.set()
        self._stop_worker_threads()
        self._simulate_halted = False
        self.state.set_monitor_idle_until(0)
        self.state.state = AutomationState.IDLE
        self._save_session_state()
        self._save_decision_history()

    def reset_records(self):
        self.stop_all()
        self.last_bet_color = None
        self.last_bet_value = None
        self.last_bet_amount = None
        self.last_result = None
        self.last_c1_boxes = []
        self.c1_history = []
        self.pending_round_number = 1
        self.round_count = 0
        self.win_count = 0
        self.lose_count = 0
        self.profit_total = 0.0
        self.loss_streak = 0
        self.martingale_index = 0
        self.last_prediction = "None"
        self.last_decision_reason = "Waiting for C1 history"
        self.last_decision_score = 0.0
        self.last_decision_gap = 0.0
        self.last_skip_reason = ""
        self.start_time = time.time()
        self.total_clicks = 0
        self.decision_history = []
        self.decision_stats = DecisionStats()
        self.state.set_game_state(None)
        self.state.set_monitor_idle_until(0)
        self.state.update_status("Records reset. Status set to Idle.")
        
        if self.app and hasattr(self.app, 'config_dir'):
            session_path = self.app.config_dir / "session_backup.json"
            if session_path.exists():
                session_path.unlink()

    def start_simulation(self) -> bool:
        if not self.capture_mgr.is_fully_calibrated():
            return False
        if not self.capture_mgr.validate_calibration():
            self.state.update_status("Calibration validation failed - points off-screen")
            return False
        if self._simulate_thread and self._simulate_thread.is_alive() and not self._stop_event.is_set():
            return True
        if self._simulate_thread and self._simulate_thread.is_alive():
            self._simulate_thread.join(timeout=2)
        self._stop_event.clear()
        self._simulate_halted = False
        self.state.state = AutomationState.SIMULATING
        self._simulate_thread = threading.Thread(target=self._simulate_round, name="SimulateThread", daemon=True)
        self._simulate_thread.start()
        return True

    def start_autoclick(self) -> bool:
        if not self.capture_mgr.is_fully_calibrated():
            return False
        if not self.capture_mgr.validate_calibration():
            self.state.update_status("Calibration validation failed - points off-screen")
            return False
        if self._autoclick_thread and self._autoclick_thread.is_alive() and not self._stop_event.is_set():
            return True
        if self._autoclick_thread and self._autoclick_thread.is_alive():
            self._autoclick_thread.join(timeout=2)
        self._stop_event.clear()
        self._simulate_halted = False
        self.state.state = AutomationState.AUTOCLICKING
        self._autoclick_thread = threading.Thread(target=self._autoclick_loop, name="AutoClickThread", daemon=True)
        self._autoclick_thread.start()
        return True
    
    def _get_confidence_level(self, score: float, gap: float) -> str:
        if score >= self.config.strategy_min_score + 1.5 and gap >= self.config.strategy_min_gap + 0.5:
            return "HIGH"
        elif score >= self.config.strategy_min_score and gap >= self.config.strategy_min_gap:
            return "MEDIUM"
        elif score > 0:
            return "LOW"
        return "SKIP"
    
    def _calculate_color_scores(self, game_state: GameState) -> Dict[str, float]:
        if not game_state or not game_state.columns:
            return {}
        
        scores = {color: 0.0 for color in self.config.color_labels}
        column_weights = (1.60, 1.25, 0.95, 0.75, 0.55, 0.40, 0.28)
        recent_focus = {0: 0.55, 1: 0.30, 2: 0.15}
        
        for column_index, column in enumerate(game_state.columns[:self.config.total_columns]):
            counts = Counter(color for color in column.boxes if color in self.config.color_labels)
            if not counts:
                continue
            
            base_weight = column_weights[min(column_index, len(column_weights) - 1)]
            for color, count in counts.items():
                scores[color] += base_weight * count
                if count >= 2:
                    scores[color] += base_weight * 0.35 * (count - 1)
                if column_index in recent_focus:
                    scores[color] += recent_focus[column_index] * count
        
        recent_c1 = self.c1_history[-4:]
        history_weights = (0.90, 0.65, 0.45, 0.30)
        for history_index, c1_boxes in enumerate(reversed(recent_c1)):
            counts = Counter(color for color in c1_boxes if color in self.config.color_labels)
            history_weight = history_weights[min(history_index, len(history_weights) - 1)]
            for color, count in counts.items():
                scores[color] += history_weight * count
        
        return scores
    
    def _record_decision(self, game_state: GameState, chosen_color: Optional[str], 
                         amount: int, reason: str, reaction_time_ms: float = 0):
        scores = self._calculate_color_scores(game_state)
        top_score = max(scores.values()) if scores else 0
        sorted_scores = sorted(scores.values(), reverse=True)
        gap = sorted_scores[0] - sorted_scores[1] if len(sorted_scores) > 1 else 0
        
        decision = DecisionRecord(
            timestamp=time.time(),
            round_number=self.pending_round_number,
            predicted_color=chosen_color,
            actual_c1_boxes=list(game_state.columns[0].boxes) if game_state and game_state.columns else [],
            bet_amount=amount if chosen_color else 0,
            decision_score=top_score,
            decision_gap=gap,
            confidence_level=self._get_confidence_level(top_score, gap),
            decision_reason=reason,
            outcome="PENDING",
            reaction_time_ms=reaction_time_ms
        )
        
        self.decision_history.append(decision)
        self.decision_stats.total_decisions += 1
        
        if chosen_color:
            self.decision_stats.bets_placed += 1
            if decision.confidence_level == "HIGH":
                self.decision_stats.high_conf_bets += 1
            elif decision.confidence_level == "MEDIUM":
                self.decision_stats.medium_conf_bets += 1
            else:
                self.decision_stats.low_conf_bets += 1
        else:
            self.decision_stats.bets_skipped += 1
        
        if len(self.decision_history) > 1000:
            self.decision_history = self.decision_history[-1000:]
        
        if self.learning_mode and self.decision_stats.total_decisions % 50 == 0 and self.decision_stats.total_decisions > 0:
            self._adjust_thresholds()
        
        if self.decision_stats.total_decisions % 100 == 0:
            self._save_decision_history()
    
    def _adjust_thresholds(self):
        if len(self.decision_history) < 50:
            return
        
        recent = self.decision_history[-50:]
        recent_bets = [d for d in recent if d.predicted_color]
        skip_rate = (len(recent) - len(recent_bets)) / len(recent) if recent else 0.0
        
        if len(recent_bets) < 20:
            return
        
        high_conf_bets = [d for d in recent_bets if d.confidence_level == "HIGH"]
        med_conf_bets = [d for d in recent_bets if d.confidence_level == "MEDIUM"]
        low_conf_bets = [d for d in recent_bets if d.confidence_level == "LOW"]
        close_gap_bets = [d for d in recent_bets if d.decision_gap <= self.config.strategy_min_gap + 0.20]
        
        high_conf_wins = len([d for d in high_conf_bets if d.outcome == "WIN"])
        med_conf_wins = len([d for d in med_conf_bets if d.outcome == "WIN"])
        low_conf_wins = len([d for d in low_conf_bets if d.outcome == "WIN"])
        close_gap_wins = len([d for d in close_gap_bets if d.outcome == "WIN"])
        
        high_win_rate = high_conf_wins / len(high_conf_bets) if high_conf_bets else 0
        med_win_rate = med_conf_wins / len(med_conf_bets) if med_conf_bets else 0
        low_win_rate = low_conf_wins / len(low_conf_bets) if low_conf_bets else 0
        close_gap_win_rate = close_gap_wins / len(close_gap_bets) if close_gap_bets else 0
        
        old_min_score = self.config.strategy_min_score
        old_min_gap = self.config.strategy_min_gap
        old_recent_cols = self.config.strategy_recent_columns_required

        if high_win_rate > 0.65 and med_win_rate > 0.55:
            self.config.strategy_min_score = min(5.0, self.config.strategy_min_score + 0.1)
            logger.info(f" Increasing min_score to {self.config.strategy_min_score:.2f} (high win rate)")
        elif high_win_rate < 0.45 and med_win_rate < 0.40:
            self.config.strategy_min_score = max(2.0, self.config.strategy_min_score - 0.15)
            logger.info(f" Decreasing min_score to {self.config.strategy_min_score:.2f} (low win rate)")

        if len(close_gap_bets) >= 12:
            if close_gap_win_rate < 0.45:
                self.config.strategy_min_gap = min(1.60, self.config.strategy_min_gap + 0.05)
                logger.info(f" Increasing min_gap to {self.config.strategy_min_gap:.2f} (close races underperform)")
            elif close_gap_win_rate > 0.60 and skip_rate > 0.30:
                self.config.strategy_min_gap = max(0.30, self.config.strategy_min_gap - 0.05)
                logger.info(f" Decreasing min_gap to {self.config.strategy_min_gap:.2f} (close races performing well)")

        if skip_rate > 0.60 and high_win_rate > 0.58 and self.config.strategy_recent_columns_required > 1:
            self.config.strategy_recent_columns_required -= 1
            logger.info(
                " Relaxing recent column requirement to %s (skip rate %.1f%%)",
                self.config.strategy_recent_columns_required,
                skip_rate * 100,
            )
        elif skip_rate < 0.20 and low_win_rate < 0.35 and self.config.strategy_recent_columns_required < 3:
            self.config.strategy_recent_columns_required += 1
            logger.info(
                " Tightening recent column requirement to %s (low-confidence bets underperform)",
                self.config.strategy_recent_columns_required,
            )

        self.config.strategy_min_score = max(2.0, min(5.0, self.config.strategy_min_score))
        self.config.strategy_min_gap = max(0.30, min(1.60, self.config.strategy_min_gap))
        self.config.strategy_recent_columns_required = max(1, min(3, self.config.strategy_recent_columns_required))

        changes = []
        if abs(old_min_score - self.config.strategy_min_score) > 0.01:
            changes.append(f"min_score {old_min_score:.2f} → {self.config.strategy_min_score:.2f}")
        if abs(old_min_gap - self.config.strategy_min_gap) > 0.01:
            changes.append(f"min_gap {old_min_gap:.2f} → {self.config.strategy_min_gap:.2f}")
        if old_recent_cols != self.config.strategy_recent_columns_required:
            changes.append(
                f"recent_cols {old_recent_cols} → {self.config.strategy_recent_columns_required}"
            )

        if changes:
            self.state.update_status(" Adaptive threshold adjusted: " + ", ".join(changes))
            if self.app:
                self.app.config_dirty = True
    
    def _save_decision_history(self):
        if not self.app or not hasattr(self.app, 'config_dir'):
            return
        
        history_path = self.app.config_dir / f"decision_history_{datetime.now().strftime('%Y%m%d')}.csv"
        
        try:
            with open(history_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow([
                    "Timestamp", "Round", "Predicted", "Actual C1", "Bet Amount",
                    "Score", "Gap", "Confidence", "Outcome", "Multiplier",
                    "Profit", "Reaction Ms", "Reason"
                ])
                
                for decision in self.decision_history:
                    writer.writerow([
                        datetime.fromtimestamp(decision.timestamp).isoformat(),
                        decision.round_number,
                        decision.predicted_color or "SKIP",
                        "/".join(decision.actual_c1_boxes),
                        decision.bet_amount,
                        f"{decision.decision_score:.2f}",
                        f"{decision.decision_gap:.2f}",
                        decision.confidence_level,
                        decision.outcome,
                        decision.multiplier,
                        f"{decision.profit_change:.2f}",
                        f"{decision.reaction_time_ms:.0f}",
                        decision.decision_reason[:100]
                    ])
        except Exception as e:
            logger.warning(f"Failed to save decision history: {e}")
    
    def _update_decision_outcome(self, round_number: int, c1_boxes: List[str], 
                                  multiplier: int, profit_change: float):
        for decision in self.decision_history:
            if decision.round_number == round_number:
                decision.outcome = "WIN" if multiplier > 0 else "LOSS"
                decision.multiplier = multiplier
                decision.profit_change = profit_change
                decision.actual_c1_boxes = c1_boxes
                
                if decision.confidence_level == "HIGH" and decision.outcome == "WIN":
                    self.decision_stats.high_conf_wins += 1
                elif decision.confidence_level == "MEDIUM" and decision.outcome == "WIN":
                    self.decision_stats.medium_conf_wins += 1
                elif decision.confidence_level == "LOW" and decision.outcome == "WIN":
                    self.decision_stats.low_conf_wins += 1
                break
    
    def _predict_color_from_game_state(self, game_state: Optional[GameState]) -> Tuple[Optional[str], str]:
        if not game_state or not game_state.columns:
            return None, "No stable board data available"

        scores = self._calculate_color_scores(game_state)
        
        if not scores:
            return None, "No color data available"

        ranked = sorted(scores.items(), key=lambda item: item[1], reverse=True)
        top_color, top_score = ranked[0]
        second_score = ranked[1][1] if len(ranked) > 1 else 0.0
        score_gap = top_score - second_score

        recent_columns = game_state.columns[:3]
        top_recent_hits = sum(
            1
            for column in recent_columns
            if top_color in column.boxes
        )

        if top_score < self.config.strategy_min_score:
            return None, f"Weak board signal ({top_color} score {top_score:.2f})"

        if score_gap < self.config.strategy_min_gap:
            return None, f"Close board race ({top_color} {top_score:.2f} vs {ranked[1][0]} {second_score:.2f})"

        if top_recent_hits < self.config.strategy_recent_columns_required:
            return None, (
                f"{top_color} only in {top_recent_hits} of C1-C3, "
                f"need {self.config.strategy_recent_columns_required}"
            )

        return top_color, f"Board pick {top_color}: score {top_score:.2f}, gap {score_gap:.2f}"
    
    def _choose_next_bet(self, game_state: Optional[GameState] = None) -> Tuple[Optional[str], int, Dict]:
        start_time = time.time()
        
        chosen_color, reason = self._predict_color_from_game_state(game_state)
        amount = self.bet_amount_steps[self.martingale_index]
        
        scores = self._calculate_color_scores(game_state) if game_state else {}
        top_score = max(scores.values()) if scores else 0
        sorted_scores = sorted(scores.values(), reverse=True)
        gap = sorted_scores[0] - sorted_scores[1] if len(sorted_scores) > 1 else 0
        confidence = self._get_confidence_level(top_score, gap)
        
        alternatives = []
        if len(sorted_scores) > 1:
            for color, score in sorted(scores.items(), key=lambda x: x[1], reverse=True)[1:4]:
                alternatives.append(f"{color}:{score:.1f}")
        
        decision_metadata = {
            "score": top_score,
            "gap": gap,
            "confidence": confidence,
            "alternatives": alternatives,
            "martingale_step": self.martingale_index + 1,
            "loss_streak": self.loss_streak,
            "recent_win_rate": self.win_count / self.round_count if self.round_count > 0 else 0
        }
        
        reaction_time = (time.time() - start_time) * 1000
        
        if game_state:
            self._record_decision(game_state, chosen_color, amount, reason, reaction_time)
        
        if chosen_color:
            self.last_decision_reason = (
                f"{reason} | Conf:{confidence} Score:{top_score:.1f} "
                f"Gap:{gap:.1f} | Alt: {', '.join(alternatives[:2])}"
            )
        else:
            self.last_decision_reason = f"{reason} (Score:{top_score:.1f} Gap:{gap:.1f})"
        
        self.last_decision_score = top_score
        self.last_decision_gap = gap
        
        return chosen_color, amount, decision_metadata

    def _record_c1_boxes_result(self, c1_boxes: List[str], prefix: str) -> bool:
        self.last_result = "/".join(c1_boxes)
        self.last_c1_boxes = list(c1_boxes)
        self.c1_history.append(list(c1_boxes))
        self.c1_history = self.c1_history[-30:]
        
        if not self.last_bet_color:
            return False
        
        self.round_count += 1
        base_stake = self._current_stake_value()
        
        matches = sum(1 for box in c1_boxes if box == self.last_bet_color)
        
        if matches == 3:
            multiplier = 3
        elif matches == 2:
            multiplier = 2
        elif matches == 1:
            multiplier = 1
        else:
            multiplier = 0
        
        if multiplier > 0:
            profit_change = base_stake * multiplier
            self.win_count += 1
            self.loss_streak = 0
            self.martingale_index = 0
            self.profit_total += profit_change
            result = "WIN"
        else:
            profit_change = -base_stake
            self.lose_count += 1
            self.loss_streak += 1
            self.profit_total += profit_change
            result = "LOSE"
            
            if self.loss_streak >= self.max_loss_streak:
                self.state.update_status(f" HALTED: {self.loss_streak} consecutive losses")
                self._simulate_halted = True
                self._stop_event.set()
            else:
                self.martingale_index = min(self.martingale_index + 1, len(self.bet_amount_steps) - 1)
        
        self._update_decision_outcome(self.round_count, c1_boxes, multiplier, profit_change)
        
        decision = next((d for d in self.decision_history if d.round_number == self.round_count), None)
        if decision:
            status_msg = (
                f"{prefix} {result}: {self.last_bet_color} vs C1 {c1_boxes} "
                f"| {multiplier}x | {decision.confidence_level} conf "
                f"(score:{decision.decision_score:.1f}) | "
                f"Profit: {profit_change:+.2f} (Total: {self.profit_total:.2f})"
            )
        else:
            status_msg = f"{prefix} {result}: {self.last_bet_color} vs C1 {c1_boxes} | Profit: {profit_change:+.2f}"
        
        self.state.update_status(status_msg)
        
        self._append_simulation_csv(
            mode=prefix,
            round_number=self.round_count,
            c1_result=self.last_result,
            color_betted=self.last_bet_color,
            amount=self.last_bet_amount or self.last_bet_value or "",
            result=f"{result} (x{multiplier})" if multiplier > 1 else result,
            lose_streak=self.loss_streak if result == "LOSE" else 0,
            multiplier=multiplier,
            profit_change=profit_change,
            total_profit=self.profit_total,
            decision_score=decision.decision_score if decision else 0,
            score_gap=decision.decision_gap if decision else 0,
            confidence=decision.confidence_level if decision else "UNKNOWN",
            decision_reason=self.last_decision_reason,
            skip_reason=self.last_skip_reason,
        )
        
        self._save_session_state()
        self.pending_round_number = self.round_count + 1
        
        if self.round_count % 50 == 0:
            self._log_decision_metrics()
        
        return True
    
    def _log_decision_metrics(self):
        if self.decision_stats.total_decisions == 0:
            return
        
        logger.info("=" * 60)
        logger.info("DECISION QUALITY METRICS")
        logger.info("=" * 60)
        logger.info(f"Total Decisions: {self.decision_stats.total_decisions}")
        logger.info(f"Bets Placed: {self.decision_stats.bets_placed} ({self.decision_stats.bets_placed/self.decision_stats.total_decisions*100:.1f}%)")
        logger.info(f"Bets Skipped: {self.decision_stats.bets_skipped} ({self.decision_stats.bets_skipped/self.decision_stats.total_decisions*100:.1f}%)")
        logger.info(f"")
        logger.info(f"High Confidence: {self.decision_stats.high_conf_bets} bets, {self.decision_stats.high_conf_wins} wins ({self.decision_stats.high_conf_win_rate*100:.1f}%)")
        logger.info(f"Medium Confidence: {self.decision_stats.medium_conf_bets} bets, {self.decision_stats.medium_conf_wins} wins ({self.decision_stats.medium_conf_win_rate*100:.1f}%)")
        logger.info(f"Low Confidence: {self.decision_stats.low_conf_bets} bets, {self.decision_stats.low_conf_wins} wins ({self.decision_stats.low_conf_win_rate*100:.1f}%)")
        logger.info("=" * 60)
        
        if self.app and hasattr(self.app, 'event_logger'):
            self.app.event_logger.log_event(
                "DECISION_METRICS",
                f"Decision quality report at round {self.round_count}",
                total_decisions=self.decision_stats.total_decisions,
                bets_placed=self.decision_stats.bets_placed,
                high_conf_win_rate=f"{self.decision_stats.high_conf_win_rate*100:.1f}%",
                medium_conf_win_rate=f"{self.decision_stats.medium_conf_win_rate*100:.1f}%",
                current_threshold=self.config.strategy_min_score
            )
    
    def get_decision_analytics(self) -> Dict:
        if len(self.decision_history) == 0:
            return {"status": "No decisions recorded yet"}
        
        recent = self.decision_history[-100:]
        recent_bets = [d for d in recent if d.predicted_color]
        reaction_times = [d.reaction_time_ms for d in recent if d.reaction_time_ms > 0]
        
        analytics = {
            "total_decisions": self.decision_stats.total_decisions,
            "bets_placed": self.decision_stats.bets_placed,
            "skip_rate": self.decision_stats.bets_skipped / self.decision_stats.total_decisions if self.decision_stats.total_decisions > 0 else 0,
            "high_conf_win_rate": self.decision_stats.high_conf_win_rate,
            "medium_conf_win_rate": self.decision_stats.medium_conf_win_rate,
            "low_conf_win_rate": self.decision_stats.low_conf_win_rate,
            "avg_decision_time_ms": statistics.mean(reaction_times) if reaction_times else 0,
            "current_thresholds": {
                "min_score": self.config.strategy_min_score,
                "min_gap": self.config.strategy_min_gap,
                "recent_columns": self.config.strategy_recent_columns_required
            },
            "learning_mode": self.learning_mode
        }
        
        if self.decision_stats.high_conf_win_rate < 0.45 and self.decision_stats.high_conf_bets > 20:
            analytics["suggestion"] = " High confidence bets performing poorly - consider lowering min_score"
        elif self.decision_stats.high_conf_win_rate > 0.65 and self.decision_stats.high_conf_bets > 20:
            analytics["suggestion"] = " High confidence bets performing well - thresholds working"
        elif self.decision_stats.bets_skipped / self.decision_stats.total_decisions > 0.7:
            analytics["suggestion"] = " Skipping too many rounds - try lowering min_score"
        
        return analytics

    def _current_stake_value(self) -> float:
        if not self.last_bet_amount:
            return 0.0

        amount_text = "".join(ch if ch.isdigit() or ch == "." else " " for ch in self.last_bet_amount)
        try:
            amount = float(amount_text.split()[0])
        except (IndexError, ValueError):
            return 0.0

        return amount

    def _is_100_confidence_round(self, game_state: GameState) -> bool:
        return (
            bool(game_state.columns)
            and not game_state.any_unknown
            and game_state.all_columns_full
            and game_state.confidence_score >= 100
        )

    def _get_simulation_image_path(self) -> Path:
        base_dir = self.app.config_dir if self.app else Path(__file__).resolve().parent
        return base_dir / "simulate_round_detector.png"

    def _get_simulation_csv_path(self) -> Path:
        base_dir = self.app.config_dir if self.app else Path(__file__).resolve().parent
        return base_dir / "simulate_results.csv"

    def _capture_100_confidence_round(self, save_image: bool) -> Optional[GameState]:
        with self.capture_mgr.capture_region() as (screenshot, bbox):
            if screenshot is None:
                return None
                
            game_state = self.game_analyzer.analyze_game_state(screenshot, bbox)
            self.state.set_game_state(game_state)

            if not self._is_100_confidence_round(game_state):
                return None

            if save_image:
                screenshot.save(self._get_simulation_image_path())

            return game_state

    def _is_full_gray_board(self, game_state: Optional[GameState]) -> bool:
        if not game_state or not game_state.columns:
            return False

        return all(
            box == self.config.gray_reference_label
            for column in game_state.columns
            for box in column.boxes
        )

    def _handle_gray_board_cooldown(self, prefix: str) -> bool:
        had_pending_bet = bool(self.last_bet_color)
        if had_pending_bet:
            self._clear_pending_bet()

        message = (
            f"{prefix}: gray board detected, pending bet cleared. Cooldown {GRAY_COOLDOWN_SECONDS:.0f}s"
            if had_pending_bet
            else f"{prefix}: gray board detected. Cooldown {GRAY_COOLDOWN_SECONDS:.0f}s"
        )
        self.state.update_status(message)
        self.state.set_monitor_idle_until(GRAY_COOLDOWN_SECONDS)

        while not self._stop_event.is_set() and self.state.get_monitor_idle_remaining() > 0:
            time.sleep(1)

        return True

    def _append_simulation_csv(self, **kwargs):
        csv_path = self._get_simulation_csv_path()
        csv_path.parent.mkdir(parents=True, exist_ok=True)
        
        try:
            needs_header = not csv_path.exists() or csv_path.stat().st_size == 0
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            with open(csv_path, "a", newline="") as f:
                writer = csv.writer(f)
                if needs_header:
                    writer.writerow([
                        "Timestamp", "Mode", "Round", "C1 Result", "Color Bet", "Amount",
                        "Result", "Loss Streak", "Multiplier", "Profit Change", "Total Profit",
                        "Decision Score", "Score Gap", "Confidence", "Decision Reason", "Skip Reason"
                    ])
                writer.writerow([
                    timestamp,
                    kwargs.get("mode", ""),
                    kwargs.get("round_number", ""),
                    kwargs.get("c1_result", ""),
                    kwargs.get("color_betted", ""),
                    kwargs.get("amount", ""),
                    kwargs.get("result", ""),
                    kwargs.get("lose_streak", 0),
                    kwargs.get("multiplier", 1),
                    f"{kwargs.get('profit_change', 0):.2f}",
                    f"{kwargs.get('total_profit', 0):.2f}",
                    f"{kwargs.get('decision_score', 0):.2f}",
                    f"{kwargs.get('score_gap', 0):.2f}",
                    kwargs.get("confidence", ""),
                    kwargs.get("decision_reason", "")[:200],
                    kwargs.get("skip_reason", "")[:100]
                ])
        except Exception as e:
            logger.warning(f"CSV write error: {e}")

    def _record_simulated_bet(self, chosen_color: str, bet_amount_label: str, use_x2: bool):
        self.last_bet_color = chosen_color
        amount = bet_amount_label.replace("Bet ", "")
        self.last_bet_amount = amount
        self.last_bet_value = f"{bet_amount_label}{' + X2' if use_x2 else ''}"
        self.state.update_status(f"SIMULATED BET R{self.pending_round_number}: {chosen_color} / {self.last_bet_value}")

    def _execute_autoclick_bet(self, chosen_color: str, target_amount: int) -> bool:
        extra_points = self.capture_mgr.get_extra_points()

        try:
            placements = build_bet_plan(target_amount)
            actions = create_click_actions(extra_points, chosen_color, placements)
            
            self.total_clicks += len(actions)
            
            completed = perform_click_actions(
                actions,
                marker_callback=self.app.show_click_marker if self.app else None,
                stop_requested=self._stop_event.is_set,
            )
            if not completed:
                self.state.update_status("AutoClick stopped before the bet finished.")
                return False

            self.last_bet_color = chosen_color
            self.last_bet_amount = str(target_amount)
            self.last_bet_value = format_bet_plan(placements)
            status_message = (
                f"AUTOCLICK BET R{self.pending_round_number}: {chosen_color} / "
                f"{target_amount} [{self.last_bet_value}]"
            )
            self.state.update_status(status_message)

            if self.app and hasattr(self.app, "event_logger"):
                self.app.event_logger.log_event(
                    "AUTOCLICK_BET",
                    status_message,
                    round_number=self.pending_round_number,
                    bet_color=chosen_color,
                    bet_amount=target_amount,
                    click_plan=self.last_bet_value,
                )

            self._log_performance()
            self._save_session_state()
            
            return True
        except ClickPlanError as exc:
            self.state.update_status(f"AutoClick planning error: {exc}")
            logger.error("AutoClick planning error: %s", exc)
            return False
        except Exception as exc:
            self.state.update_status(f"AutoClick click error: {exc}")
            logger.error("AutoClick click error: %s", exc)
            return False

    def _clear_pending_bet(self):
        self.last_bet_color = None
        self.last_bet_amount = None
        self.last_bet_value = None

    def _skip_pending_bet(self, prefix: str):
        skipped_round_number = self.pending_round_number
        self._clear_pending_bet()
        self.last_skip_reason = self.last_decision_reason
        self.state.update_status(f"{prefix} SKIP R{skipped_round_number}: {self.last_decision_reason}")
        
        self._append_simulation_csv(
            mode=prefix,
            round_number=skipped_round_number,
            c1_result=self.last_result or "",
            color_betted="",
            amount="",
            result="SKIP",
            lose_streak=self.loss_streak,
            multiplier=0,
            profit_change=0.0,
            total_profit=self.profit_total,
            decision_score=self.last_decision_score,
            score_gap=self.last_decision_gap,
            decision_reason=self.last_decision_reason,
            skip_reason=self.last_skip_reason,
        )
        
        self.round_count = skipped_round_number
        self.pending_round_number = self.round_count + 1

    def _monitor_loop(self):
        logger.info("Monitor loop started")
        blank_trigger_armed = False

        while not self._stop_event.is_set():
            idle_remaining = self.state.get_monitor_idle_remaining()
            if idle_remaining > 0:
                time.sleep(1)
                continue

            with self.capture_mgr.capture_region() as (screenshot, bbox):
                if screenshot is None:
                    time.sleep(self.config.column_check_interval)
                    continue
                    
                game_state = self.game_analyzer.analyze_game_state(screenshot, bbox)
                self.state.set_game_state(game_state)

                if game_state.blank_detected:
                    if not blank_trigger_armed:
                        self.state.update_status(" Waiting for next round...")
                    blank_trigger_armed = True
                    continue

                if (
                    blank_trigger_armed
                    and game_state.columns
                    and not game_state.any_unknown
                    and game_state.all_columns_full
                    and game_state.confidence_score >= 100
                ):
                    self.state.update_status(" STABLE BOARD DETECTED")

                    try:
                        c1_boxes = list(game_state.columns[0].boxes)
                        self._record_c1_boxes_result(c1_boxes, prefix="LIVE")
                    except Exception:
                        logger.exception("Failed to record LIVE round result")

                    chosen_color, target_amount, _ = self._choose_next_bet(game_state)

                    if chosen_color:
                        self.state.update_status(
                            f"LIVE READY R{self.pending_round_number}: {chosen_color} / {target_amount}"
                        )
                    else:
                        self.state.update_status(
                            f"LIVE SKIP R{self.pending_round_number}: {self.last_decision_reason}"
                        )

                    blank_trigger_armed = False
                    self.state.set_monitor_idle_until(self.config.monitor_idle_seconds)

            time.sleep(self.config.column_check_interval)

        logger.info("Monitor loop stopped")

    def _simulate_round(self):
        try:
            first_round = True

            while not self._stop_event.is_set():
                self._ensure_brave_on_top("simulate")
                game_state = self._capture_100_confidence_round(save_image=False)

                if game_state is None:
                    time.sleep(self.config.column_check_interval)
                    continue

                if self._is_full_gray_board(game_state):
                    self._handle_gray_board_cooldown("SIMULATE")
                    self.state.update_status("Simulate: waiting for next 100% confidence round...")
                    continue

                time.sleep(1)

                if first_round:
                    self.state.update_status("SIMULATE: first 100% detected, placing virtual round 1 bet")
                    first_round = False
                else:
                    confirmed_state = self._capture_100_confidence_round(save_image=True)
                    if confirmed_state is None:
                        self.state.update_status("SIMULATE: detector changed after delay, waiting again")
                        continue
                    if self._is_full_gray_board(confirmed_state):
                        self._handle_gray_board_cooldown("SIMULATE")
                        self.state.update_status("Simulate: waiting for next 100% confidence round...")
                        continue
                    c1_boxes = list(confirmed_state.columns[0].boxes)
                    self._record_c1_boxes_result(c1_boxes, prefix="SIMULATE")
                    if self._stop_event.is_set():
                        break

                chosen_color, target_amount, _ = self._choose_next_bet(game_state)
                if chosen_color:
                    self._record_simulated_bet(chosen_color, f"Bet {target_amount}", False)
                else:
                    self._skip_pending_bet("SIMULATE")

                time.sleep(1)
                self.state.set_monitor_idle_until(self.config.monitor_idle_seconds)
                self.state.update_status(f"Simulate countdown: {self.config.monitor_idle_seconds:.0f}s")

                while not self._stop_event.is_set() and self.state.get_monitor_idle_remaining() > 0:
                    time.sleep(1)

                self.state.update_status("Simulate: waiting for next 100% confidence round...")

            if self._simulate_halted:
                self.state.state = AutomationState.IDLE
            elif self._stop_event.is_set():
                self.state.update_status("SIMULATE STOPPED")
                self.state.state = AutomationState.IDLE
        except Exception as e:
            logger.error(f"Simulation error: {e}")
            self.state.update_status(f"Simulation error: {e}")
            self.state.state = AutomationState.IDLE

    def _autoclick_loop(self):
        try:
            first_round = True
            self.decision_history = []
            self.decision_stats = DecisionStats()

            while not self._stop_event.is_set():
                self._ensure_brave_on_top("autoclick")
                game_state = self._capture_100_confidence_round(save_image=False)

                if game_state is None:
                    time.sleep(self.config.column_check_interval)
                    continue

                if self._is_full_gray_board(game_state):
                    self._handle_gray_board_cooldown("AUTOCLICK")
                    self.state.update_status("AutoClick: waiting for next 100% confidence round...")
                    continue

                time.sleep(1)

                if first_round:
                    self.state.update_status("AUTOCLICK: first 100% detected, placing round 1 bet")
                    first_round = False
                else:
                    confirmed_state = self._capture_100_confidence_round(save_image=True)
                    if confirmed_state is None:
                        self.state.update_status("AUTOCLICK: detector changed after delay, waiting again")
                        continue
                    if self._is_full_gray_board(confirmed_state):
                        self._handle_gray_board_cooldown("AUTOCLICK")
                        self.state.update_status("AutoClick: waiting for next 100% confidence round...")
                        continue
                    c1_boxes = list(confirmed_state.columns[0].boxes)
                    self._record_c1_boxes_result(c1_boxes, prefix="AUTOCLICK")
                    if self._stop_event.is_set():
                        break

                chosen_color, target_amount, decision_meta = self._choose_next_bet(game_state)
                
                if chosen_color:
                    if not self._check_bet_limits(target_amount):
                        self._stop_event.set()
                        self.state.state = AutomationState.IDLE
                        break
                    
                    logger.info(f"Decision: {chosen_color} @ {target_amount} | "
                               f"Conf:{decision_meta['confidence']} Score:{decision_meta['score']:.1f} "
                               f"Gap:{decision_meta['gap']:.1f} | Alt:{decision_meta['alternatives'][:2]}")
                    
                    if not self._execute_autoclick_bet(chosen_color, target_amount):
                        self._stop_event.set()
                        self.state.state = AutomationState.IDLE
                        break
                else:
                    self._skip_pending_bet("AUTOCLICK")

                time.sleep(1)
                self.state.set_monitor_idle_until(self.config.monitor_idle_seconds)
                self.state.update_status(f"AutoClick countdown: {self.config.monitor_idle_seconds:.0f}s")

                while not self._stop_event.is_set() and self.state.get_monitor_idle_remaining() > 0:
                    time.sleep(1)

                self.state.update_status("AutoClick: waiting for next 100% confidence round...")

            self._log_decision_metrics()
            
        except Exception as e:
            logger.error(f"AutoClick error: {e}")
            self.state.update_status(f"AutoClick error: {e}")
            self.state.state = AutomationState.IDLE


class AutoClickerPro:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.config_dir = ensure_runtime_data_dir()
        migrate_legacy_runtime_files(self.config_dir)
        configure_file_logging(self.config_dir)
        self.event_logger = EventLogger(self.config_dir)
        logger.info(f"Runtime data directory: {self.config_dir}")
        
        self.config_path = self.config_dir / "app_config.json"
        self.calibration_path = self.config_dir / "calibration.json"
        
        self.config = self._load_config()
        self.config_dirty = False
        self.capture_mgr = ScreenCaptureManager(self.config)
        self.color_matcher = ColorMatcher(self.config)
        self.game_analyzer = GameAnalyzer(self.config, self.capture_mgr, self.color_matcher)
        self.engine = AutomationEngine(self.config, self.capture_mgr, self.color_matcher, self.game_analyzer, self)
        
        self._calibration_window: Optional[tk.Toplevel] = None
        self._status_update_id = None
        self.status_mode_label = "Idle"
        
        self._setup_ui()
        self._load_calibration()
        self._schedule_ui_update()
    
    def _load_config(self) -> AppConfig:
        try:
            if self.config_path.exists():
                with open(self.config_path, 'r') as f:
                    data = json.load(f)
                    app_config_data = data.get("app_config", {})
                    return AppConfig.from_dict(app_config_data)
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
        return AppConfig()
    
    def _save_config(self, force: bool = False):
        if not force and self.config_path.exists() and not self.config_dirty:
            return
        try:
            with open(self.config_path, 'w') as f:
                json.dump({"app_config": self.config.to_dict(), "version": "2.3.0", "updated": datetime.now().isoformat()}, f, indent=2)
            self.config_dirty = False
        except Exception as e:
            logger.error(f"Failed to save config: {e}")
    
    def _load_calibration(self):
        if not self.calibration_path.exists():
            return
        try:
            with open(self.calibration_path, 'r') as f:
                data = json.load(f)
            
            self.capture_mgr.clear_calibration()
            
            for i, point_data in enumerate(data.get("points", [])):
                point = CalibrationPoint.from_dict(i, point_data)
                self.capture_mgr.add_calibration_point(point)
                if point.rgb_sample and point.name in self.config.reference_color_labels:
                    self.color_matcher.set_reference(point.name, point.rgb_sample)
            
            loaded_points = len(self.capture_mgr.calibration_points)
            expected_points = self.config.total_calibration_points
            if loaded_points >= expected_points:
                self.status_var.set(f"Status: Calibration loaded ({loaded_points}/{expected_points} points)")
            else:
                self.status_var.set(f"Status: Partial calibration ({loaded_points}/{expected_points} points)")
            logger.info(f"Loaded {loaded_points} calibration points")
        except Exception as e:
            logger.error(f"Failed to load calibration: {e}")
    
    def _save_calibration(self):
        data = {"points": [
            {"name": p.name, "x": p.x, "y": p.y, "rgb_sample": list(p.rgb_sample) if p.rgb_sample else None} 
            for p in sorted(self.capture_mgr.calibration_points.values(), key=lambda p: p.index)
        ]}
        try:
            with open(self.calibration_path, 'w') as f:
                json.dump(data, f, indent=2)
            logger.info("Calibration saved")
        except Exception as e:
            logger.error(f"Failed to save calibration: {e}")
    
    def _setup_ui(self):
        self.root.title("AutoClicker Pro - Enhanced with Analytics")
        window_width = 560
        window_height = 650
        screen_width = self.root.winfo_screenwidth()
        self.root.geometry(f"{window_width}x{window_height}+{screen_width - window_width - 20}+20")
        self.root.attributes("-topmost", True)
        self.root.resizable(False, False)
        
        style = ttk.Style()
        style.theme_use('clam')
        
        title_frame = ttk.Frame(self.root)
        title_frame.pack(fill="x", padx=10, pady=(10, 5))
        ttk.Label(title_frame, text="AUTOCLICKER PRO - ENHANCED", font=("Arial", 12, "bold")).pack()
        ttk.Label(title_frame, text=f"Martingale: {self.config.martingale_start} → up to {self.config.martingale_max_steps - 1} losses", font=("Arial", 8)).pack()
        
        button_frame = ttk.Frame(self.root)
        button_frame.pack(pady=10)
        
        self.calibrate_btn = None
        self.monitor_btn = None
        self.simulate_btn = None
        self.autoclick_btn = None
        self.reset_btn = None

        button_specs = [
            ("Calibrate", self.start_calibration, "#f0ad4e", 0, 0, "calibrate"),
            ("Monitor", self.start_monitoring, "#5cb85c", 0, 1, "monitor"),
            ("Simulate", self.start_simulation, "#0275d8", 0, 2, "simulate"),
            ("AutoClick", self.start_autoclick, "#8e44ad", 1, 0, "autoclick"),
            ("Reset", self.reset_records, "#f39c12", 1, 1, None),
            ("Analytics", self.show_decision_analytics, "#6c757d", 1, 2, None),
            ("Exit", self.exit_app, "#d9534f", 2, 1, None),
        ]
        
        for text, command, color, row, column, stop_action_name in button_specs:
            btn = tk.Button(
                button_frame,
                text=text,
                command=command,
                width=12,
                bg=color,
                fg="white",
                relief="raised",
                bd=1,
            )
            btn.grid(row=row, column=column, padx=2, pady=5)

            if stop_action_name:
                btn.bind("<Double-Button-1>", lambda e, action=stop_action_name: self.stop_action(action))

            if text == "Calibrate":
                self.calibrate_btn = btn
            elif text == "Monitor":
                self.monitor_btn = btn
            elif text == "Simulate":
                self.simulate_btn = btn
            elif text == "AutoClick":
                self.autoclick_btn = btn
            elif text == "Reset":
                self.reset_btn = btn

        # Learning mode toggle
        self.learning_mode_var = tk.BooleanVar(value=False)
        learning_check = tk.Checkbutton(
            button_frame,
            text="Adaptive Learning",
            variable=self.learning_mode_var,
            command=self.toggle_learning_mode,
            bg="#f8f9fa"
        )
        learning_check.grid(row=2, column=0, padx=2, pady=5)

        status_frame = ttk.LabelFrame(self.root, text="Status", padding=(10, 5))
        status_frame.pack(fill="x", padx=10, pady=(5, 5))
        self.status_var = tk.StringVar(value="Ready - Not calibrated")
        ttk.Label(status_frame, textvariable=self.status_var, font=("Arial", 9)).pack(anchor="w")
        
        game_frame = ttk.LabelFrame(self.root, text="Game State", padding=(10, 5))
        game_frame.pack(fill="x", padx=10, pady=(5, 5))
        self.columns_var = tk.StringVar(value="Columns: Not scanned")
        ttk.Label(game_frame, textvariable=self.columns_var, font=("Arial", 8)).pack(anchor="w")
        self.columns_var_row2 = tk.StringVar(value="")
        ttk.Label(game_frame, textvariable=self.columns_var_row2, font=("Arial", 8)).pack(anchor="w")
        self.confidence_var = tk.StringVar(value="Confidence: 0%")
        ttk.Label(game_frame, textvariable=self.confidence_var, font=("Arial", 8)).pack(anchor="w")

        stats_frame = ttk.LabelFrame(self.root, text="Statistics", padding=(10, 5))
        stats_frame.pack(fill="x", padx=10, pady=(5, 5))
        self.rounds_var = tk.StringVar(value="Rounds: 0")
        self.win_lose_var = tk.StringVar(value="Wins: 0 | Loses: 0")
        self.profit_var = tk.StringVar(value="Profit: 0.00")
        self.martingale_var = tk.StringVar(value="Martingale: 5")
        self.current_bet_var = tk.StringVar(value="Current Bet: None")
        self.pending_bet_var = tk.StringVar(value="Pending Bet: None")
        self.last_c1_var = tk.StringVar(value="Last C1 Boxes: None")
        self.decision_var = tk.StringVar(value="Decision: Waiting for C1 history")
        ttk.Label(stats_frame, textvariable=self.rounds_var, font=("Arial", 8)).pack(anchor="w")
        ttk.Label(stats_frame, textvariable=self.win_lose_var, font=("Arial", 8)).pack(anchor="w")
        ttk.Label(stats_frame, textvariable=self.profit_var, font=("Arial", 8)).pack(anchor="w")
        ttk.Label(stats_frame, textvariable=self.martingale_var, font=("Arial", 8)).pack(anchor="w")
        ttk.Label(stats_frame, textvariable=self.current_bet_var, font=("Arial", 8)).pack(anchor="w")
        ttk.Label(stats_frame, textvariable=self.pending_bet_var, font=("Arial", 8)).pack(anchor="w")
        ttk.Label(stats_frame, textvariable=self.last_c1_var, font=("Arial", 8)).pack(anchor="w")
        ttk.Label(stats_frame, textvariable=self.decision_var, font=("Arial", 8), wraplength=520).pack(anchor="w")
        
        info_frame = ttk.LabelFrame(self.root, text="Information", padding=(10, 5))
        info_frame.pack(fill="both", expand=True, padx=10, pady=(5, 10))
        self.calib_info_var = tk.StringVar(value=f"Calibration: 0/{self.config.total_columns * self.config.boxes_per_column} grid + 0/{len(self.config.extra_calibration_labels)} extra")
        ttk.Label(info_frame, textvariable=self.calib_info_var, font=("Arial", 8)).pack(anchor="w")
    
    def toggle_learning_mode(self):
        self.engine.learning_mode = self.learning_mode_var.get()
        status = "ENABLED" if self.engine.learning_mode else "DISABLED"
        self.status_var.set(f"Status: Adaptive Learning {status}")
        logger.info(f"Adaptive learning mode {status}")
    
    def show_decision_analytics(self):
        analytics = self.engine.get_decision_analytics()
        
        dashboard = tk.Toplevel(self.root)
        dashboard.title("Decision Analytics Dashboard")
        dashboard.geometry("800x600")
        dashboard.attributes("-topmost", True)
        
        notebook = ttk.Notebook(dashboard)
        notebook.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Tab 1: Performance
        perf_frame = ttk.Frame(notebook)
        notebook.add(perf_frame, text="Performance")
        
        metrics_frame = ttk.LabelFrame(perf_frame, text="Real-time Metrics", padding=10)
        metrics_frame.pack(fill="x", padx=10, pady=5)
        
        metrics = [
            ("Total Decisions", analytics.get("total_decisions", 0)),
            ("Bets Placed", analytics.get("bets_placed", 0)),
            ("Skip Rate", f"{analytics.get('skip_rate', 0)*100:.1f}%"),
            ("Avg Decision Time", f"{analytics.get('avg_decision_time_ms', 0):.0f}ms"),
        ]
        
        for i, (label, value) in enumerate(metrics):
            ttk.Label(metrics_frame, text=f"{label}:", font=("Arial", 10, "bold")).grid(row=i, column=0, sticky="e", padx=5, pady=2)
            ttk.Label(metrics_frame, text=str(value), font=("Arial", 10)).grid(row=i, column=1, sticky="w", padx=5, pady=2)
        
        # Confidence breakdown
        conf_frame = ttk.LabelFrame(perf_frame, text="Win Rate by Confidence Level", padding=10)
        conf_frame.pack(fill="x", padx=10, pady=5)
        
        conf_data = [
            ("HIGH", analytics.get("high_conf_win_rate", 0), self.engine.decision_stats.high_conf_bets),
            ("MEDIUM", analytics.get("medium_conf_win_rate", 0), self.engine.decision_stats.medium_conf_bets),
            ("LOW", analytics.get("low_conf_win_rate", 0), self.engine.decision_stats.low_conf_bets),
        ]
        
        for level, rate, count in conf_data:
            color = "#28a745" if rate > 0.55 else ("#ffc107" if rate > 0.45 else "#dc3545")
            ttk.Label(conf_frame, text=f"{level}:", font=("Arial", 10, "bold")).pack(anchor="w")
            ttk.Label(conf_frame, text=f"  {rate*100:.1f}% win rate ({count} bets)", foreground=color).pack(anchor="w")
        
        # Tab 2: Thresholds
        thresh_frame = ttk.Frame(notebook)
        notebook.add(thresh_frame, text="Thresholds")
        
        thresh_display = tk.Text(thresh_frame, height=15, font=("Courier", 10))
        thresh_display.pack(fill="both", expand=True, padx=10, pady=10)
        
        thresholds = analytics.get("current_thresholds", {})
        thresh_text = f"""
Current Decision Thresholds:
{'='*40}

Min Score Required:     {thresholds.get('min_score', 0):.2f}
Min Score Gap:          {thresholds.get('min_gap', 0):.2f}
Recent Columns Required: {thresholds.get('recent_columns', 0)}

Adaptive Learning:      {'ENABLED' if analytics.get('learning_mode') else 'DISABLED'}

{'='*40}

Interpretation:
- Higher min_score = fewer bets, higher confidence
- Lower min_score = more bets, potentially lower win rate
- Score gap prevents close races where multiple colors are likely
"""
        thresh_display.insert("1.0", thresh_text)
        thresh_display.configure(state="disabled")
        
        # Tab 3: Suggestions
        suggest_frame = ttk.Frame(notebook)
        notebook.add(suggest_frame, text="Suggestions")
        
        suggestion = analytics.get("suggestion", "No suggestions at this time. Continue monitoring.")
        ttk.Label(suggest_frame, text="AI Recommendations:", font=("Arial", 12, "bold")).pack(anchor="w", padx=10, pady=10)
        ttk.Label(suggest_frame, text=suggestion, font=("Arial", 10), wraplength=700).pack(anchor="w", padx=10, pady=5)
        
        # Export button
        def export_analytics():
            export_path = self.config_dir / f"analytics_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(export_path, 'w') as f:
                json.dump(analytics, f, indent=2)
            messagebox.showinfo("Exported", f"Analytics saved to {export_path}")
        
        ttk.Button(dashboard, text="Export Analytics", command=export_analytics).pack(pady=10)
    
    def _schedule_ui_update(self):
        self._update_ui()
        self._status_update_id = self.root.after(500, self._schedule_ui_update)

    def show_click_marker(self, x: int, y: int, label: str):
        self.root.after(0, lambda: self._create_click_marker(x, y, label))

    def _create_click_marker(self, x: int, y: int, label: str):
        marker = tk.Toplevel(self.root)
        marker.overrideredirect(True)
        marker.attributes("-topmost", True)
        marker.configure(bg="#ff00ff")

        try:
            marker.wm_attributes("-transparentcolor", "#ff00ff")
        except tk.TclError:
            pass

        marker.geometry(f"80x80+{max(0, x - 40)}+{max(0, y - 40)}")

        canvas = tk.Canvas(marker, width=80, height=80, bg="#ff00ff", highlightthickness=0)
        canvas.pack(fill="both", expand=True)
        canvas.create_oval(18, 18, 62, 62, outline="#ff3b30", width=3)
        canvas.create_text(40, 11, text=label.replace("Bet ", ""), fill="#ff3b30", font=("Arial", 8, "bold"))
        marker.after(2000, marker.destroy)
    
    def _update_ui(self):
        current = len(self.capture_mgr.calibration_points)
        grid_needed = self.config.total_columns * self.config.boxes_per_column
        extra_needed = len(self.config.extra_calibration_labels)
        self.calib_info_var.set(f"Calibration: {min(current, grid_needed)}/{grid_needed} grid + {max(0, current - grid_needed)}/{extra_needed} extra")
        
        game_state = self.engine.state.get_game_state()
        if game_state and game_state.columns:
            if game_state.has_uniform_column_pattern:
                self.columns_var.set("Columns: Invalid repeated color pattern detected")
                self.columns_var_row2.set("")
            elif not game_state.any_unknown:
                formatted_columns = [f"C{col.column_index}[{':'.join(col.boxes)}]" for col in game_state.columns]
                self.columns_var.set("Columns: " + " | ".join(formatted_columns[:3]))
                self.columns_var_row2.set("         " + " | ".join(formatted_columns[3:7]))
            else:
                self.columns_var.set("Columns: Waiting for stable match...")
                self.columns_var_row2.set("")
            self.confidence_var.set(f"Confidence: {game_state.confidence_score:.1f}%")
        else:
            self.columns_var.set("Columns: Waiting for data...")
            self.columns_var_row2.set("")
            self.confidence_var.set("Confidence: 0%")

        current_bet = "None"
        if self.engine.last_bet_color:
            current_bet = self.engine.last_bet_color
            if self.engine.last_bet_value:
                current_bet = f"{current_bet} / {self.engine.last_bet_value}"

        last_c1 = "None"
        if self.engine.last_c1_boxes:
            last_c1 = " / ".join(self.engine.last_c1_boxes)

        self.rounds_var.set(f"Rounds: {self.engine.round_count}")
        self.win_lose_var.set(f"Wins: {self.engine.win_count} | Loses: {self.engine.lose_count}")
        self.profit_var.set(f"Profit: {self.engine.profit_total:.2f}")
        current_martingale = self.engine.bet_amount_steps[self.engine.martingale_index]
        self.martingale_var.set(
            f"Martingale: {current_martingale} | Loss streak: {self.engine.loss_streak}/{self.engine.max_loss_streak - 1}"
        )
        self.current_bet_var.set(f"Current Bet: {current_bet}")
        self.pending_bet_var.set(f"Pending Bet: R{self.engine.pending_round_number} - {current_bet}")
        self.last_c1_var.set(f"Last C1 Boxes: {last_c1}")
        self.decision_var.set(f"Decision: {self.engine.last_decision_reason}")
        
        idle_remaining = self.engine.state.get_monitor_idle_remaining()
        if self._calibration_window:
            self.status_var.set("Status: Calibrating")
        elif self.engine.state.state == AutomationState.IDLE:
            self.status_var.set("Status: Idle")
        elif idle_remaining > 0:
            self.status_var.set(f"Status: {self.status_mode_label} - Countdown {idle_remaining:.0f}s")
        elif self.engine.state.state in (AutomationState.MONITORING, AutomationState.SIMULATING, AutomationState.AUTOCLICKING):
            self.status_var.set(f"Status: {self.status_mode_label}")
    
    def stop_action(self, action: str):
        logger.info(f"Double-click detected on {action} - stopping")
        self.engine.stop_all()
        
        if self._calibration_window:
            try:
                self._calibration_window.destroy()
            except:
                pass
            self._calibration_window = None
        
        self.engine.state.state = AutomationState.IDLE
        
        self.status_mode_label = "Idle"
        self.status_var.set("Status: Idle (stopped)")
        
        btn = None
        if action == "calibrate":
            btn = self.calibrate_btn
        elif action == "monitor":
            btn = self.monitor_btn
        elif action == "simulate":
            btn = self.simulate_btn
        elif action == "autoclick":
            btn = self.autoclick_btn
        
        if btn:
            original_bg = btn.cget("bg")
            btn.config(bg="#ff6666")
            self.root.after(500, lambda: btn.config(bg=original_bg))
    
    def start_calibration(self):
        if self._calibration_window:
            return
        
        self.engine.stop_all()
        
        self._calibration_window = tk.Toplevel(self.root)
        self._calibration_window.title("Calibration")
        self._calibration_window.attributes("-fullscreen", True)
        
        screenshot = ImageGrab.grab().convert("RGB")
        screenshot_path = self.config_dir / "calibration_frame.png"
        screenshot.save(screenshot_path)
        
        bg_image = ImageTk.PhotoImage(screenshot)
        canvas = tk.Canvas(self._calibration_window, cursor="cross")
        canvas.pack(fill="both", expand=True)
        canvas.create_image(0, 0, image=bg_image, anchor="nw")
        canvas.bg_image = bg_image
        canvas.screenshot = screenshot
        
        temp_points = []
        
        def get_point_name(index: int) -> str:
            grid_count = self.config.total_columns * self.config.boxes_per_column
            if index < grid_count:
                col = (index // self.config.boxes_per_column) + 1
                box = (index % self.config.boxes_per_column) + 1
                return f"Column {col}, Box {box}"
            extra_idx = index - grid_count
            if extra_idx < len(self.config.extra_calibration_labels):
                return self.config.extra_calibration_labels[extra_idx]
            return f"Extra {extra_idx + 1}"
        
        instruction_var = tk.StringVar()
        
        def update_instruction_banner():
            current_index = len(temp_points)
            if current_index >= self.config.total_calibration_points:
                instruction_var.set(f"Complete: {len(temp_points)}/{self.config.total_calibration_points} points")
                return
            point_name = get_point_name(current_index)
            instruction_var.set(f"Click: {point_name} ({current_index + 1}/{self.config.total_calibration_points})")
        
        def on_click(event):
            idx = len(temp_points)
            if idx >= self.config.total_calibration_points:
                return
            
            point_name = get_point_name(idx)
            rgb_sample = None
            if point_name in self.config.reference_color_labels:
                rgb_sample = self.capture_mgr.get_pixel_rgb(screenshot, (event.x, event.y), None)
            
            point = CalibrationPoint(
                index=idx,
                name=point_name,
                x=event.x,
                y=event.y,
                rgb_sample=rgb_sample,
            )
            
            temp_points.append(point)
            self.capture_mgr.add_calibration_point(point)
            
            if rgb_sample:
                self.color_matcher.set_reference(point_name, rgb_sample)
            
            color = "red" if point_name in self.config.reference_color_labels else "yellow"
            canvas.create_oval(event.x - 5, event.y - 5, event.x + 5, event.y + 5, fill=color, outline="white")
            canvas.create_text(event.x + 10, event.y - 10, text=f"{idx + 1}", fill="white", anchor="w")
            
            remaining = self.config.total_calibration_points - len(temp_points)
            self._calibration_window.title(f"Calibration - {remaining} left")
            update_instruction_banner()
            
            if len(temp_points) >= self.config.total_calibration_points:
                self._save_calibration()
                self._calibration_window.destroy()
                self._calibration_window = None
                messagebox.showinfo("Success", f"Calibration complete! {len(temp_points)} points saved.")
        
        def on_escape(event):
            if len(temp_points) > 0:
                if messagebox.askyesno("Cancel", f"Save {len(temp_points)} points?"):
                    self._save_calibration()
            self._calibration_window.destroy()
            self._calibration_window = None
        
        canvas.bind("<Button-1>", on_click)
        self._calibration_window.bind("<Escape>", on_escape)
        
        instruction_frame = tk.Frame(self._calibration_window, bg="black", bd=1, relief="solid")
        instruction_frame.place(x=10, y=10)
        
        tk.Label(instruction_frame, textvariable=instruction_var, bg="black", fg="#ffd966",
                 font=("Arial", 14, "bold"), padx=12, pady=8).pack(anchor="w")
        
        tk.Label(self._calibration_window, text="Click points in order. Press ESC to cancel.",
                 bg="black", fg="white", font=("Arial", 11), padx=12, pady=8).place(x=10, y=58)
        update_instruction_banner()
    
    def start_monitoring(self):
        if not self.capture_mgr.is_fully_calibrated():
            messagebox.showwarning("Not Calibrated", "Please complete calibration first.")
            return

        monitor_running = (
            self.engine._monitor_thread
            and self.engine._monitor_thread.is_alive()
            and not self.engine._stop_event.is_set()
        )

        if monitor_running:
            self.engine.stop_all()
            self.status_mode_label = "Idle"
            self.status_var.set("Status: Idle")
            return

        if self.engine.state.state != AutomationState.IDLE:
            self.engine.stop_all()
        
        if self.engine.start_monitoring():
            self.status_mode_label = "Monitoring"
            self.status_var.set("Status: Monitoring")
        else:
            messagebox.showerror("Error", "Failed to start monitoring")

    def start_simulation(self):
        if not self.capture_mgr.is_fully_calibrated():
            messagebox.showwarning("Not Calibrated", "Please complete calibration first.")
            return

        simulate_running = (
            self.engine._simulate_thread
            and self.engine._simulate_thread.is_alive()
            and not self.engine._stop_event.is_set()
        )

        if simulate_running:
            self.engine.stop_all()
            self.status_mode_label = "Idle"
            self.status_var.set("Status: Idle")
            return

        if self.engine.state.state != AutomationState.IDLE:
            self.engine.stop_all()

        self.engine._ensure_brave_on_top("start simulation")

        if self.engine.start_simulation():
            self.status_mode_label = "Simulating"
            self.status_var.set("Status: Simulating")
        else:
            messagebox.showerror("Error", "Failed to start simulation")

    def start_autoclick(self):
        if not self.capture_mgr.is_fully_calibrated():
            messagebox.showwarning("Not Calibrated", "Please complete calibration first.")
            return

        autoclick_running = (
            self.engine._autoclick_thread
            and self.engine._autoclick_thread.is_alive()
            and not self.engine._stop_event.is_set()
        )

        if autoclick_running:
            self.engine.stop_all()
            self.status_mode_label = "Idle"
            self.status_var.set("Status: Idle")
            return

        if self.engine.state.state != AutomationState.IDLE:
            self.engine.stop_all()

        self.engine._ensure_brave_on_top("start autoclick")

        if self.engine.start_autoclick():
            self.status_mode_label = "AutoClick"
            self.status_var.set("Status: AutoClick")
        else:
            messagebox.showerror("Error", "Failed to start AutoClick")

    def reset_records(self):
        if self._calibration_window:
            try:
                self._calibration_window.destroy()
            except:
                pass
            self._calibration_window = None

        self.engine.reset_records()
        self.status_mode_label = "Idle"
        self.status_var.set("Status: Idle (records reset)")
    
    def exit_app(self):
        if self._status_update_id:
            self.root.after_cancel(self._status_update_id)
        self.engine.stop_all()
        self._save_config()
        self.root.quit()
        self.root.destroy()


def main():
    try:
        import PIL
        import pyautogui
    except ImportError as e:
        print(f"Missing dependency: {e}")
        print("Please install: pip install pillow pyautogui")
        return
    
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0.1
    
    root = tk.Tk()
    app = AutoClickerPro(root)
    
    try:
        root.mainloop()
    except KeyboardInterrupt:
        print("\n Shutting down gracefully...")
        app.exit_app()


if __name__ == "__main__":
    main()
